package padroescomportamentais.command;

public interface Tarefa {

    void executar();
    void cancelar();
}
