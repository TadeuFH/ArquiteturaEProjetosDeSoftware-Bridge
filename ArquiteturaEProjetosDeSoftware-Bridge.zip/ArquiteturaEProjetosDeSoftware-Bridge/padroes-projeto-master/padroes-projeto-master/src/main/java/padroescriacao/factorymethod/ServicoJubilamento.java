package padroescriacao.factorymethod;

public class ServicoJubilamento {

    public String executar() {
        return "Jubilamento efetivado";
    }

    public String cancelar() {
        return "Jubilamento cancelado";
    }
}
