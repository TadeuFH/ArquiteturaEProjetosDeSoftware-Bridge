package padroescriacao.factorymethodex1;

public class Pentagono implements Poligono{
    public String getDescripition() {
        return "Pentagono";
    }
}
