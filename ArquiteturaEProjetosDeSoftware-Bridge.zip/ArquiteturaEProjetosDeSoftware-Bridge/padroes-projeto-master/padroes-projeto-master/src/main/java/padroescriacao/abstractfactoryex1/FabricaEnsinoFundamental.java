package padroescriacao.abstractfactoryex1;

public class FabricaEnsinoFundamental implements FabricaAbstrata{

    @Override
    public Disciplina createDisciplina() {
        return new DisciplinaEnsinoFundamental();
    }

    @Override
    public Nota createNota() {
        return new NotaEnsinoFundamental();
    }

}
