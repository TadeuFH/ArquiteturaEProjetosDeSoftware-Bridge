package padroesestruturais.decoratorex1;

public interface Hamburger {
    public String getDescription();
    public double getCost();
}


