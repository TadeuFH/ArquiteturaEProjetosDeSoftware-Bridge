package padroesestruturais.bridgeex1;

public class Red implements Color {
    @Override
    public String getColor() {
        return "red";
    }
}