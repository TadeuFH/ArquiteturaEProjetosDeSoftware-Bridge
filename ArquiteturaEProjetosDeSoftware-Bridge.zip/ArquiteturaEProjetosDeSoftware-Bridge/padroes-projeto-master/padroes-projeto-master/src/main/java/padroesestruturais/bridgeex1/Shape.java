package padroesestruturais.bridgeex1;

public interface Shape {
    String draw();
}
