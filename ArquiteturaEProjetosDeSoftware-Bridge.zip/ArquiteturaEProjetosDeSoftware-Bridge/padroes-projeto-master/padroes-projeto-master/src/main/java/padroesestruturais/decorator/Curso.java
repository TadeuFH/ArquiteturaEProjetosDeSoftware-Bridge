package padroesestruturais.decorator;

public interface Curso {

    float getCargaHoraria();
    String getEstrutura();

}
